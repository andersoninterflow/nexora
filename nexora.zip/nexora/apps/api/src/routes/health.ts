import { FastifyInstance } from 'fastify';

async function healthRoutes(server: FastifyInstance) {
  server.get('/health', async () => {
    return { success: true, data: { status: 'ok' }, error: null };
  });
}

export default healthRoutes;