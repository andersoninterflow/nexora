import { FastifyInstance } from 'fastify';
import { z } from 'zod';
import bcrypt from 'bcryptjs';
import { env } from '../utils/env.js';

const createUserSchema = z.object({
  email: z.string().email(),
  password: z.string().min(6),
  name: z.string().min(1),
  roles: z.array(z.string()).default(['viewer']),
});

async function userRoutes(server: FastifyInstance) {
  // lista usuários (apenas admin)
  server.get('/', { preHandler: [server.authenticate] }, async (request, reply) => {
    const userRoles = request.user?.roles || [];
    if (!userRoles.includes('admin')) {
      return reply.status(403).send({ success: false, data: null, error: { code: 'FORBIDDEN', message: 'Acesso negado' } });
    }
    const users = await server.prisma.user.findMany({ select: { id: true, email: true, name: true, createdAt: true, updatedAt: true, roles: { include: { role: true } } } });
    const result = users.map(u => ({
      id: u.id,
      email: u.email,
      name: u.name,
      roles: u.roles.map(r => r.role.name),
      createdAt: u.createdAt.toISOString(),
      updatedAt: u.updatedAt.toISOString(),
    }));
    return reply.send({ success: true, data: result, error: null });
  });

  // obter usuário atual
  server.get('/me', { preHandler: [server.authenticate] }, async (request, reply) => {
    const userId = request.user!.sub;
    const user = await server.prisma.user.findUnique({ where: { id: userId }, include: { roles: { include: { role: true } } } });
    if (!user) {
      return reply.status(404).send({ success: false, data: null, error: { code: 'NOT_FOUND', message: 'Usuário não encontrado' } });
    }
    const result = {
      id: user.id,
      email: user.email,
      name: user.name,
      roles: user.roles.map(r => r.role.name),
      createdAt: user.createdAt.toISOString(),
      updatedAt: user.updatedAt.toISOString(),
    };
    return reply.send({ success: true, data: result, error: null });
  });

  // cria usuário (apenas admin)
  server.post('/', { preHandler: [server.authenticate] }, async (request, reply) => {
    const userRoles = request.user?.roles || [];
    if (!userRoles.includes('admin')) {
      return reply.status(403).send({ success: false, data: null, error: { code: 'FORBIDDEN', message: 'Acesso negado' } });
    }
    const parse = createUserSchema.safeParse(request.body);
    if (!parse.success) {
      return reply.status(400).send({ success: false, data: null, error: { code: 'INVALID_PAYLOAD', message: 'Payload inválido' } });
    }
    const { email, password, name, roles } = parse.data;
    // Verifica e-mails permitidos, se configurado
    if (env.ALLOWED_EMAILS) {
      const allowed = env.ALLOWED_EMAILS.split(',').map(e => e.trim()).filter(Boolean);
      if (allowed.length > 0 && !allowed.includes(email)) {
        return reply.status(400).send({ success: false, data: null, error: { code: 'EMAIL_NOT_ALLOWED', message: 'E-mail não autorizado' } });
      }
    }
    const hashed = await bcrypt.hash(password, 10);
    const created = await server.prisma.user.create({
      data: {
        email,
        password: hashed,
        name,
        roles: {
          create: roles.map(r => ({ role: { connect: { name: r } } })),
        },
      },
      include: { roles: { include: { role: true } } },
    });
    const result = {
      id: created.id,
      email: created.email,
      name: created.name,
      roles: created.roles.map(r => r.role.name),
      createdAt: created.createdAt.toISOString(),
      updatedAt: created.updatedAt.toISOString(),
    };
    return reply.status(201).send({ success: true, data: result, error: null });
  });
}

export default userRoutes;