import { FastifyInstance } from 'fastify';
import { z } from 'zod';
import bcrypt from 'bcryptjs';
import { env } from '../utils/env.js';

const loginSchema = z.object({
  email: z.string().email(),
  password: z.string().min(6),
});

const refreshSchema = z.object({ refreshToken: z.string() });

async function authRoutes(server: FastifyInstance) {
  // Login
  server.post('/login', async (request, reply) => {
    const parse = loginSchema.safeParse(request.body);
    if (!parse.success) {
      return reply.status(400).send({ success: false, data: null, error: { code: 'INVALID_PAYLOAD', message: 'Payload inválido' } });
    }
    const { email, password } = parse.data;
    const user = await server.prisma.user.findUnique({ where: { email }, include: { roles: { include: { role: true } } } });
    if (!user) {
      return reply.status(400).send({ success: false, data: null, error: { code: 'INVALID_CREDENTIALS', message: 'Credenciais inválidas' } });
    }
    const match = await bcrypt.compare(password, user.password);
    if (!match) {
      return reply.status(400).send({ success: false, data: null, error: { code: 'INVALID_CREDENTIALS', message: 'Credenciais inválidas' } });
    }
    const roles = user.roles.map(r => r.role.name);
    const accessToken = server.jwt.sign({ sub: user.id, email: user.email, roles }, { expiresIn: Number(env.JWT_EXPIRES_IN) });
    const refreshToken = server.jwt.sign({ sub: user.id }, { secret: env.JWT_REFRESH_SECRET, expiresIn: Number(env.JWT_REFRESH_EXPIRES_IN) });
    // Armazena refresh token no banco
    await server.prisma.refreshToken.create({
      data: {
        token: refreshToken,
        user: { connect: { id: user.id } },
        expiresAt: new Date(Date.now() + Number(env.JWT_REFRESH_EXPIRES_IN) * 1000),
      },
    });
    return reply.send({ success: true, data: { accessToken, refreshToken }, error: null });
  });

  // Refresh token
  server.post('/refresh', async (request, reply) => {
    const parse = refreshSchema.safeParse(request.body);
    if (!parse.success) {
      return reply.status(400).send({ success: false, data: null, error: { code: 'INVALID_PAYLOAD', message: 'Payload inválido' } });
    }
    const { refreshToken } = parse.data;
    try {
      const payload = server.jwt.verify(refreshToken, { secret: env.JWT_REFRESH_SECRET }) as { sub: string; iat: number; exp: number };
      const record = await server.prisma.refreshToken.findUnique({ where: { token: refreshToken } });
      if (!record || record.revoked || record.expiresAt < new Date()) {
        return reply.status(401).send({ success: false, data: null, error: { code: 'INVALID_TOKEN', message: 'Refresh token inválido' } });
      }
      const user = await server.prisma.user.findUnique({ where: { id: payload.sub }, include: { roles: { include: { role: true } } } });
      if (!user) {
        return reply.status(401).send({ success: false, data: null, error: { code: 'INVALID_TOKEN', message: 'Usuário não encontrado' } });
      }
      const roles = user.roles.map(r => r.role.name);
      const accessToken = server.jwt.sign({ sub: user.id, email: user.email, roles }, { expiresIn: Number(env.JWT_EXPIRES_IN) });
      return reply.send({ success: true, data: { accessToken }, error: null });
    } catch (err) {
      return reply.status(401).send({ success: false, data: null, error: { code: 'INVALID_TOKEN', message: 'Refresh token inválido' } });
    }
  });

  // Logout
  server.post('/logout', async (request, reply) => {
    const parse = refreshSchema.safeParse(request.body);
    if (!parse.success) {
      return reply.status(400).send({ success: false, data: null, error: { code: 'INVALID_PAYLOAD', message: 'Payload inválido' } });
    }
    const { refreshToken } = parse.data;
    await server.prisma.refreshToken.updateMany({ where: { token: refreshToken }, data: { revoked: true } });
    return reply.send({ success: true, data: { message: 'Logout realizado' }, error: null });
  });
}

export default authRoutes;