import Fastify from 'fastify';
import cors from '@fastify/cors';
import swagger from '@fastify/swagger';
import jwt from '@fastify/jwt';
import { env } from './utils/env.js';
import { logger } from './utils/logger.js';
import { prismaPlugin } from './plugins/prisma.js';
import { authPlugin } from './plugins/auth.js';
import healthRoutes from './routes/health.js';
import authRoutes from './routes/auth.js';
import userRoutes from './routes/user.js';

const buildServer = () => {
  const server = Fastify({ logger });

  // Configurações de CORS
  server.register(cors, {
    origin: env.CORS_ORIGIN || '*',
    credentials: true,
  });

  // Swagger para documentação OpenAPI
  server.register(swagger, {
    swagger: {
      info: {
        title: 'NEXORA API',
        description: 'API Gateway do Ecossistema NEXORA',
        version: '0.1.0',
      },
      host: 'localhost:' + env.API_PORT,
      basePath: '/v1',
      schemes: ['http'],
    },
    exposeRoute: true,
    routePrefix: '/docs',
  });

  // Registra plugins
  server.register(prismaPlugin);
  server.register(authPlugin);

  // Registra rotas
  server.register(healthRoutes, { prefix: '/v1' });
  server.register(authRoutes, { prefix: '/v1/auth' });
  server.register(userRoutes, { prefix: '/v1/users' });

  return server;
};

// Inicia o servidor
async function start() {
  const server = buildServer();
  try {
    await server.listen({ port: Number(env.API_PORT) || 3000, host: '0.0.0.0' });
    console.log(`Servidor rodando em http://localhost:${env.API_PORT}`);
  } catch (err) {
    server.log.error(err);
    process.exit(1);
  }
}

if (process.env.NODE_ENV !== 'test') {
  start();
}

export default buildServer;