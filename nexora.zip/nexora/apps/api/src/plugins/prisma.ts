import fp from 'fastify-plugin';
import { PrismaClient } from '@prisma/client';

// Instância única do Prisma para uso nos handlers
const prisma = new PrismaClient();

export interface PrismaPluginOptions {}

export const prismaPlugin = fp<PrismaPluginOptions>(async (server) => {
  // Decora o servidor com o cliente Prisma
  server.decorate('prisma', prisma);
  // Desconecta no fechamento
  server.addHook('onClose', async (instance) => {
    await instance.prisma.$disconnect();
  });
});

declare module 'fastify' {
  interface FastifyInstance {
    prisma: PrismaClient;
  }
}