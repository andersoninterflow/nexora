import fp from 'fastify-plugin';
import { FastifyReply, FastifyRequest } from 'fastify';
import jwtPlugin from '@fastify/jwt';
import { env } from '../utils/env.js';

export const authPlugin = fp(async (server) => {
  // Registra plugin JWT
  server.register(jwtPlugin, {
    secret: env.JWT_SECRET,
    sign: {
      expiresIn: Number(env.JWT_EXPIRES_IN),
    },
  });

  // Decora função para autenticação
  server.decorate('authenticate', async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      await request.jwtVerify();
    } catch (err) {
      reply.status(401).send({ success: false, data: null, error: { code: 'UNAUTHORIZED', message: 'Token inválido' } });
    }
  });
});

declare module 'fastify' {
  interface FastifyInstance {
    authenticate: (request: FastifyRequest, reply: FastifyReply) => Promise<void>;
  }
  interface FastifyRequest {
    user?: {
      sub: string;
      email: string;
      roles: string[];
      iat: number;
      exp: number;
    };
  }
}