import dotenv from 'dotenv';

// Carrega variáveis de ambiente do arquivo .env
dotenv.config();

function getEnv(key: string, defaultValue?: string): string {
  const value = process.env[key] || defaultValue;
  if (value === undefined || value === null) {
    throw new Error(`Variável de ambiente ${key} não definida`);
  }
  return value;
}

export const env = {
  API_PORT: getEnv('API_PORT', '3000'),
  DATABASE_URL: getEnv('DATABASE_URL'),
  REDIS_URL: getEnv('REDIS_URL'),
  JWT_SECRET: getEnv('JWT_SECRET'),
  JWT_REFRESH_SECRET: getEnv('JWT_REFRESH_SECRET'),
  JWT_EXPIRES_IN: getEnv('JWT_EXPIRES_IN', '900'),
  JWT_REFRESH_EXPIRES_IN: getEnv('JWT_REFRESH_EXPIRES_IN', '604800'),
  CORS_ORIGIN: getEnv('CORS_ORIGIN', '*'),
  ALLOWED_EMAILS: getEnv('ALLOWED_EMAILS', ''),
};