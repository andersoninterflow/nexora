import { logger as baseLogger } from '@nexora/logger';

// Simple wrapper to expose a unified logger for the API
export const logger = baseLogger.child({ service: 'api' });