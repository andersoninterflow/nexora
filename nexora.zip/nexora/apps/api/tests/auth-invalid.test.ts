import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import buildServer from '../src/main.js';

describe('auth routes - invalid payloads', () => {
  let server: any;
  beforeAll(() => {
    server = buildServer();
  });
  afterAll(async () => {
    await server.close();
  });
  it('login should return 400 when payload is invalid', async () => {
    const res = await server.inject({ method: 'POST', url: '/v1/auth/login', payload: { email: 'foo' } });
    expect(res.statusCode).toBe(400);
  });
  it('refresh should return 400 when no token', async () => {
    const res = await server.inject({ method: 'POST', url: '/v1/auth/refresh', payload: {} });
    expect(res.statusCode).toBe(400);
  });
});