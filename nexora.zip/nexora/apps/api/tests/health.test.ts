import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import buildServer from '../src/main.js';

describe('health route', () => {
  let server: any;
  beforeAll(() => {
    server = buildServer();
  });
  afterAll(async () => {
    await server.close();
  });
  it('should return ok', async () => {
    const res = await server.inject({ method: 'GET', url: '/v1/health' });
    expect(res.statusCode).toBe(200);
    const json = res.json();
    expect(json.success).toBe(true);
    expect(json.data.status).toBe('ok');
  });
});