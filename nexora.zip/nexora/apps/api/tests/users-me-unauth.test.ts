import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import buildServer from '../src/main.js';

describe('users/me route - unauthorized', () => {
  let server: any;
  beforeAll(() => {
    server = buildServer();
  });
  afterAll(async () => {
    await server.close();
  });
  it('GET /v1/users/me should require authentication', async () => {
    const res = await server.inject({ method: 'GET', url: '/v1/users/me' });
    expect(res.statusCode).toBe(401);
  });
});