import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import buildServer from '../src/main.js';

describe('logout route', () => {
  let server: any;
  beforeAll(() => {
    server = buildServer();
  });
  afterAll(async () => {
    await server.close();
  });
  it('POST /v1/auth/logout should return 400 when no token', async () => {
    const res = await server.inject({ method: 'POST', url: '/v1/auth/logout', payload: {} });
    expect(res.statusCode).toBe(400);
  });
});