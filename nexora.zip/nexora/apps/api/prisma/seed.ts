import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  // Cria papéis básicos se não existirem
  const adminRole = await prisma.role.upsert({
    where: { name: 'admin' },
    update: {},
    create: {
      name: 'admin',
      description: 'Administrador com todas as permissões',
    },
  });
  const viewerRole = await prisma.role.upsert({
    where: { name: 'viewer' },
    update: {},
    create: {
      name: 'viewer',
      description: 'Usuário com permissões de visualização',
    },
  });

  // Verifica se já existe um usuário admin
  const existingAdmin = await prisma.user.findFirst({ where: { email: 'admin@nexora.local' } });
  if (!existingAdmin) {
    const hashed = await bcrypt.hash('admin123', 10);
    const user = await prisma.user.create({
      data: {
        email: 'admin@nexora.local',
        password: hashed,
        name: 'Admin',
        roles: {
          create: {
            role: {
              connect: { id: adminRole.id },
            },
          },
        },
      },
    });
    console.log(`Usuário administrador criado: ${user.email}`);
  } else {
    console.log('Usuário administrador já existe');
  }
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });