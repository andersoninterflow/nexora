# API do Ecossistema NEXORA

Este documento descreve os principais endpoints da API **NEXORA**.  Todas as respostas seguem um formato consistente:

```json
{
  "success": true,
  "data": {},
  "error": null,
  "meta": {}
}
```

Quando ocorre um erro, `success` é `false` e o campo `error` contém um código e uma mensagem descritiva.

## Autenticação

### `POST /v1/auth/login`

Realiza login de um usuário e retorna os tokens de acesso e refresh.

- **Body**:
  ```json
  {
    "email": "usuario@example.com",
    "password": "senha123"
  }
  ```
- **Resposta (200)**:
  ```json
  {
    "success": true,
    "data": {
      "accessToken": "<jwt>",
      "refreshToken": "<jwt_refresh>"
    },
    "error": null
  }
  ```
- **Códigos de erro**:
  - `400 INVALID_CREDENTIALS`: email ou senha incorretos
  - `400 INVALID_PAYLOAD`: corpo inválido

### `POST /v1/auth/refresh`

Gera um novo access token a partir de um refresh token válido.

- **Body**:
  ```json
  { "refreshToken": "<jwt_refresh>" }
  ```
- **Resposta (200)**:
  ```json
  {
    "success": true,
    "data": { "accessToken": "<novo_jwt>" },
    "error": null
  }
  ```
- **Códigos de erro**:
  - `400 INVALID_PAYLOAD`: corpo inválido
  - `401 INVALID_TOKEN`: refresh token inválido ou revogado

### `POST /v1/auth/logout`

Revoga o refresh token fornecido.

- **Body**:
  ```json
  { "refreshToken": "<jwt_refresh>" }
  ```
- **Resposta (200)**:
  ```json
  {
    "success": true,
    "data": { "message": "Logout realizado" },
    "error": null
  }
  ```

## Usuários

### `GET /v1/users/me`

Retorna os dados do usuário autenticado.  Requer `Authorization: Bearer <accessToken>` no header.

- **Resposta (200)**:
  ```json
  {
    "success": true,
    "data": {
      "id": "uuid",
      "email": "usuario@example.com",
      "name": "Nome",
      "roles": ["viewer"]
    },
    "error": null
  }
  ```
- **Códigos de erro**:
  - `401 UNAUTHORIZED`: token ausente ou inválido
  - `404 NOT_FOUND`: usuário não encontrado

### `GET /v1/users`

Lista todos os usuários.  Requer que o usuário autenticado tenha o papel `admin`.

- **Resposta (200)**:
  ```json
  {
    "success": true,
    "data": [
      {
        "id": "uuid",
        "email": "admin@nexora.local",
        "name": "Admin",
        "roles": ["admin"]
      },
      ...
    ],
    "error": null
  }
  ```
- **Códigos de erro**:
  - `401 UNAUTHORIZED`: token ausente ou inválido
  - `403 FORBIDDEN`: usuário não possui permissão

### `POST /v1/users`

Cria um novo usuário.  Requer papel `admin`.

- **Body**:
  ```json
  {
    "email": "novo@example.com",
    "password": "senha123",
    "name": "Novo Usuário",
    "roles": ["viewer"]
  }
  ```
- **Resposta (201)**:
  ```json
  {
    "success": true,
    "data": {
      "id": "uuid",
      "email": "novo@example.com",
      "name": "Novo Usuário",
      "roles": ["viewer"]
    },
    "error": null
  }
  ```
- **Códigos de erro**:
  - `400 INVALID_PAYLOAD`: payload inválido
  - `400 EMAIL_NOT_ALLOWED`: email não autorizado
  - `401 UNAUTHORIZED`: token ausente ou inválido
  - `403 FORBIDDEN`: usuário não possui permissão

## Rotas de Saúde e Observabilidade

### `GET /v1/health`

Retorna o status básico da API.  Pode ser utilizado por load balancers e sistemas de monitoramento.

- **Resposta (200)**:
  ```json
  { "success": true, "data": { "status": "ok" }, "error": null }
  ```

### `GET /docs`

Exibe a documentação interativa (Swagger UI) gerada a partir das declarações de rotas.  Útil para explorar a API de forma interativa.

---

Esta documentação é apenas um guia de referência inicial.  Consulte o código fonte e os testes para obter detalhes adicionais sobre validação de campos, mensagens de erro e comportamento de cada rota.