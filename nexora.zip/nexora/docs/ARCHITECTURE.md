# Arquitetura

Este documento descreve a visão macro e detalhada do Ecossistema Digital **NEXORA**.  A arquitetura segue princípios de microsserviços, mas o MVP se inicia como monolito modular.  À medida que o projeto evolui, cada módulo poderá ser desacoplado em serviços independentes.

## Visão de Contexto

```mermaid
graph TD
  usuário(Usuário) -->|HTTP| frontend[Frontend (Next.js)]
  frontend -->|HTTP| api[API Gateway / Backend (Fastify)]
  api --> auth[Serviço de Autenticação]
  api --> notificações[Serviço de Notificações]
  api --> observabilidade[Observabilidade]
  api --> db[(PostgreSQL)]
  api --> cache[(Redis)]
  notificações -->|SMTP/Webhook| provedor[Provedor externo]
```

## Visão de Containers

Cada bloco do ecossistema roda em seu próprio container, orquestrado pelo Docker Compose:

```mermaid
graph LR
  subgraph Compose
    db[(PostgreSQL)]
    redis[(Redis)]
    api[[API Gateway]]
    web[[Frontend (Next.js)]]
    notifications[[Serviço de Notificações]]
  end
  api --> db
  api --> redis
  web --> api
  notifications --> api
```

## Fluxo de Autenticação

O processo de autenticação utiliza tokens **JWT** com access token e refresh token, conforme ilustrado abaixo.  Essa abordagem é inspirada em exemplos da comunidade Fastify【60372359636951†L67-L137】.

```mermaid
sequenceDiagram
  participant U as Usuário
  participant FE as Frontend
  participant API as API
  participant DB as Banco
  participant JWT as JWT

  U->>FE: envia email/senha
  FE->>API: POST /v1/auth/login
  API->>DB: valida usuário e senha
  DB-->>API: usuário válido
  API->>JWT: gera accessToken e refreshToken
  JWT-->>API: tokens
  API-->>FE: { accessToken, refreshToken }
  FE->>API: requisição protegida (/v1/users/me)
  API->>JWT: valida accessToken
  JWT-->>API: ok
  API-->>FE: dados protegidos
  Note over FE,API: accessToken expirou?
  FE->>API: POST /v1/auth/refresh (envia refreshToken)
  API->>JWT: valida refreshToken
  JWT-->>API: ok
  API->>JWT: gera novo accessToken
  API-->>FE: novo accessToken
```

## Domínios e Módulos

- **Usuários**: criação, listagem e consulta de usuários.  As senhas são sempre armazenadas com hash forte.
- **Autenticação**: login, refresh e logout.  Tokens são assinados com chaves definidas nas variáveis de ambiente.
- **Autorização**: RBAC com papéis (ex: `admin`, `viewer`) e permissões associadas.
- **Notificações**: envio de e‑mails e gatilhos de webhook.
- **Observabilidade**: middleware de logs estruturados e coleta de métricas.

## Evolução para Microsserviços

Embora o MVP esteja organizado em um único repositório com múltiplos apps, cada serviço (API, notificações, web) poderá ser extraído para seu próprio repositório ou implantado de forma independente.  O uso de filas (por exemplo, RabbitMQ ou Kafka) poderá ser adicionado para desacoplar processos de longa duração.
