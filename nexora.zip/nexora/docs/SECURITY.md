# Segurança do Ecossistema NEXORA

Este documento descreve as práticas de segurança adotadas no Ecossistema Digital **NEXORA**.  A base destas recomendações segue as melhores práticas de engenharia de software e de segurança da informação, bem como orientações de especialistas.

## Armazenamento de Segredos

- **Variáveis de ambiente**: Os segredos (como senhas de banco, chaves JWT, tokens de e‑mail) **nunca devem ser versionados** no repositório.  Em vez disso, são carregados em tempo de execução via variáveis de ambiente definidas em um arquivo `.env`.  Fornecemos um arquivo `.env.example` com as chaves necessárias; este arquivo não contém valores sensíveis, servindo como modelo para sua configuração local【471439090401850†L24-L92】.  Dessa forma, cada ambiente (desenvolvimento, staging e produção) mantém seus próprios segredos isolados【471439090401850†L24-L92】.
- **Gerenciador de segredos**: Para ambientes de produção, recomenda‑se utilizar serviços dedicados (AWS Secrets Manager, HashiCorp Vault, GCP Secret Manager) em vez de arquivos `.env`.  Estes serviços fornecem rotação automática de chaves, auditoria e controle de acesso granular.

## Autenticação e Autorização

- **Hash de senhas**: As senhas dos usuários são armazenadas com algoritmo de hash forte (`bcrypt`) e sal aleatório.  Nunca armazenamos ou transmitimos senhas em texto claro.
- **Tokens JWT**: A autenticação utiliza *access tokens* e *refresh tokens* assinados com chaves secretas configuradas nas variáveis de ambiente.  Os *access tokens* têm curta duração (15 minutos por padrão) e os *refresh tokens* têm duração maior (7 dias).  O refresh token é armazenado no banco para que possa ser revogado em caso de comprometimento.  Essa abordagem segue boas práticas de projetos Fastify com JWT【60372359636951†L67-L137】.
- **RBAC**: A autorização é baseada em papéis (Role‑Based Access Control).  Cada usuário possui um conjunto de papéis que concedem permissões específicas.  Os papéis são controlados pelo administrador e consultados em cada rota protegida.  Rotas sensíveis (como criação de usuários) exigem o papel `admin`.

## Validação e Sanitização

- **Validação de entrada**: Todas as rotas validam os dados de entrada utilizando a biblioteca `zod`.  Isso impede que campos inesperados ou formatos incorretos sejam processados, reduzindo a superfície de ataques de *injection*.
- **Sanitização**: Campos de texto fornecidos pelo usuário devem ser sanitizados antes de serem registrados em logs ou enviados por e‑mail.  Evite registrar informações sensíveis.

## Proteção contra Abuso

- **Rate limiting**: Rotas sensíveis, como login e refresh de tokens, devem ter limites de requisições por IP.  Embora o rate limiting não esteja implementado no MVP, a estrutura permite adicionar o plugin `@fastify/rate-limit` para configurar limites, mitigando ataques de força bruta.
- **CORS restrito**: As políticas de CORS são configuradas via variável de ambiente `CORS_ORIGIN`.  Para produção, defina apenas os domínios autorizados a consumir a API.

## Logs e Auditoria

- **Logs estruturados**: Utilizamos a biblioteca Pino para gerar logs em formato JSON.  Cada requisição recebe um `requestId` e, quando autenticado, o `userId` é incluído nos logs.  Isso facilita a correlação entre eventos e evita perda de contexto.
- **Traces e métricas**: A observabilidade da aplicação pode ser estendida com ferramentas como OpenTelemetry para coletar métricas e traces distribuídos.  No MVP, apenas logs estão habilitados.
- **Auditoria**: A cada ação sensível (login, criação de usuário, alteração de papéis, geração de API keys) é criado um registro na tabela `AuditLog`, permitindo rastreamento e compliance.

## Boas Práticas Adicionais

- **Uso de HTTPS**: Em ambientes de produção, a API deve estar atrás de um servidor que forneça TLS (HTTPS).  Isso protege os tokens e dados sensíveis durante o transporte.
- **Atualizações**: Mantenha as dependências atualizadas para mitigar vulnerabilidades conhecidas.  Ferramentas como Dependabot podem alertar para atualizações de segurança.
- **Revisão de código e testes**: Qualquer modificação no código passa por pipeline de CI que executa lint e testes.  Recomenda‑se análise de código estático e revisão manual para detectar potenciais falhas de segurança.

Seguindo estas práticas, o Ecossistema NEXORA oferece uma base segura que pode ser expandida conforme a necessidade de seu produto.