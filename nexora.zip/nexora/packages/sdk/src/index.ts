import fetch, { HeadersInit } from 'node-fetch';
import type { ApiResponse, User } from '@nexora/shared';

export class NexoraClient {
  private baseUrl: string;
  private accessToken: string | null = null;
  private refreshToken: string | null = null;

  constructor(baseUrl: string) {
    this.baseUrl = baseUrl.replace(/\/$/, '');
  }

  private buildHeaders(extra?: HeadersInit): HeadersInit {
    const headers: HeadersInit = {
      'Content-Type': 'application/json',
    };
    if (this.accessToken) {
      headers['Authorization'] = `Bearer ${this.accessToken}`;
    }
    return { ...headers, ...extra };
  }

  async login(email: string, password: string) {
    const res = await fetch(`${this.baseUrl}/v1/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password }),
    });
    const json = (await res.json()) as ApiResponse<{ accessToken: string; refreshToken: string }>;
    if (json.success && json.data) {
      this.accessToken = json.data.accessToken;
      this.refreshToken = json.data.refreshToken;
    }
    return json;
  }

  async refresh() {
    if (!this.refreshToken) {
      throw new Error('Sem refresh token');
    }
    const res = await fetch(`${this.baseUrl}/v1/auth/refresh`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ refreshToken: this.refreshToken }),
    });
    const json = (await res.json()) as ApiResponse<{ accessToken: string }>;
    if (json.success && json.data) {
      this.accessToken = json.data.accessToken;
    }
    return json;
  }

  async getCurrentUser() {
    const res = await fetch(`${this.baseUrl}/v1/users/me`, {
      headers: this.buildHeaders(),
    });
    return (await res.json()) as ApiResponse<User>;
  }

  async listUsers() {
    const res = await fetch(`${this.baseUrl}/v1/users`, {
      headers: this.buildHeaders(),
    });
    return res.json() as Promise<ApiResponse<User[]>>;
  }
}