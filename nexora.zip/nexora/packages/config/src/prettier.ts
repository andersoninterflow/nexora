import { Options } from 'prettier';

const config: Options = {
  singleQuote: true,
  semi: true,
  trailingComma: 'all',
  arrowParens: 'avoid',
  printWidth: 100,
};

export default config;