import { useEffect, useState } from 'react';
import axios from 'axios';

export default function Business() {
  const [data, setData] = useState(null);
  useEffect(() => {
    axios.get('http://localhost:8000/business/pj')
      .then((res) => setData(res.data))
      .catch((err) => console.error(err));
  }, []);
  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1>Módulo Business</h1>
      <p>Gestão empresarial: ERP simplificado, finanças, RH e CRM.</p>
      {data && (
        <pre style={{ background: '#f5f5f5', padding: '1rem' }}>
          {JSON.stringify(data, null, 2)}
        </pre>
      )}
    </div>
  );
}