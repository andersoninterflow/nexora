import { useEffect, useState } from 'react';
import axios from 'axios';

export default function Cadastro() {
  const [data, setData] = useState(null);
  useEffect(() => {
    axios.get('http://localhost:8000/cadastro/pf')
      .then((res) => setData(res.data))
      .catch((err) => console.error(err));
  }, []);
  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1>Módulo Cadastro</h1>
      <p>Este módulo permite o registro de usuários e empresas.</p>
      {data && (
        <pre style={{ background: '#f5f5f5', padding: '1rem' }}>
          {JSON.stringify(data, null, 2)}
        </pre>
      )}
    </div>
  );
}