import { useEffect, useState } from 'react';
import axios from 'axios';

export default function Social() {
  const [data, setData] = useState(null);
  useEffect(() => {
    axios.get('http://localhost:8000/social/pf')
      .then((res) => setData(res.data))
      .catch((err) => console.error(err));
  }, []);
  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1>Módulo Social</h1>
      <p>Rede social integrada ao ecossistema.</p>
      {data && (
        <pre style={{ background: '#f5f5f5', padding: '1rem' }}>
          {JSON.stringify(data, null, 2)}
        </pre>
      )}
    </div>
  );
}