import Link from 'next/link';

export default function Home() {
  const modules = [
    'cadastro',
    'life',
    'social',
    'chat',
    'move',
    'ia',
    'pay',
    'marketplace',
    'job',
    'business',
    'mini_business',
    'school',
    'plug',
    'trainer'
  ];
  return (
    <div style={{ padding: '2rem', fontFamily: 'sans-serif' }}>
      <h1>NEXORA Ecossistema (v10)</h1>
      <p>Bem‑vindo! Escolha um módulo para explorar:</p>
      <ul>
        {modules.map((m) => (
          <li key={m} style={{ marginBottom: '0.5rem' }}>
            <Link href={`/${m.replace('_', '-')}`}>{m.replace('_', ' ')}</Link>
          </li>
        ))}
      </ul>
    </div>
  );
}