# Frontend NEXORA (v10)

Este diretório contém a aplicação web do ecossistema NEXORA, construída com Next.js. Ela fornece páginas para cada módulo do projeto e demonstra chamadas à API.

## Scripts úteis

- `npm run dev` – inicia o servidor de desenvolvimento em `http://localhost:3000`.
- `npm run build` – gera a build de produção.
- `npm start` – inicia a versão de produção.

Para interagir com a API local, certifique‑se de que o backend FastAPI esteja rodando em `http://localhost:8000`.