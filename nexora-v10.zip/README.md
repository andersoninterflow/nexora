# NEXORA – Ecossistema Digital (Versão 10)

**Slogan:** Onde tudo se conecta com inteligência.

Esta é a décima iteração do ecossistema NEXORA, um monorepo robusto pronto para implantação em larga escala. A estrutura foi concebida para escalar módulos de serviços para pessoas físicas, pessoas jurídicas e administradores, além de integrar facilmente novas funcionalidades.

## Visão geral

O projeto está dividido em dois principais aplicativos:

* **backend/** – API escrita em **Python** com **FastAPI**, contendo rotas para cada módulo do ecossistema e preparada para autenticação, RBAC e persistência de dados.
* **frontend/** – Aplicação web em **Next.js** (React) que apresenta páginas para cada módulo e interage com a API.

Além disso, há arquivos de infraestrutura para orquestração com Docker Compose e Kubernetes, além de integração contínua via GitHub Actions.

## Módulos principais

O ecossistema é composto pelos seguintes módulos. Cada módulo possui rotas para Pessoa Física (**pf**), Pessoa Jurídica (**pj**) e Painel do Administrador (**admin**):

| Módulo         | Descrição rápida                                                                  |
| -------------- | ------------------------------------------------------------------------------- |
| Cadastro       | Porta de entrada do sistema: criação de contas, validação de identidade e permissões |
| Life           | Ferramentas de bem‑estar, saúde digital e rotina                                  |
| Social         | Rede social integrada com perfis, comunidades e eventos                           |
| Chat           | Comunicação segura com chat, áudio, vídeo e bots                                 |
| Move           | Mobilidade inteligente para transporte e logística                                |
| IA             | Assistentes e automação por inteligência artificial                               |
| Pay            | Sistema financeiro integrado com carteira digital, pagamentos e recebimentos       |
| Marketplace    | Compra e venda de produtos e serviços                                             |
| Job            | Módulo de oportunidades de trabalho e freelances                                  |
| Business       | ERP simplificado com finanças, RH e CRM para empresas                             |
| Mini Business  | Solução enxuta para pequenos negócios e autônomos                                 |
| School         | Plataforma de educação digital com cursos e trilhas                               |
| Plug           | Integrações externas via APIs e plugins                                           |
| Trainer        | Mentoria e treinamento para indivíduos e equipes                                  |

Para mais detalhes sobre cada módulo e seus serviços, consulte `docs/modules_overview.md`.

## Quickstart (local)

### Pré‑requisitos

* [Docker](https://www.docker.com/) e [Docker Compose](https://docs.docker.com/compose/)
* Node.js (>= 18) e npm se desejar executar o frontend sem Docker
* Python 3.10+ se desejar executar o backend sem Docker

### Execução com Docker Compose

1. Clone este repositório:

   ```bash
   git clone https://github.com/SEU_USUARIO/nexora.git
   cd nexora
   ```

2. Construa e inicie os serviços:

   ```bash
   docker compose up --build
   ```

3. Acesse os serviços nos seguintes endereços:

   * API: `http://localhost:8000/docs` – documentação interativa gerada pelo FastAPI.
   * Frontend: `http://localhost:3000` – interface web.

### Execução manual (sem Docker)

#### Backend

```bash
cd backend
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --reload
```

#### Frontend

```bash
cd frontend
npm install
npm run dev
```

## Estrutura de repositório

```
nexora-v10/
├── backend/            # API FastAPI com módulos
│   ├── main.py
│   ├── modules/
│   │   ├── __init__.py
│   │   ├── cadastro.py
│   │   ├── life.py
│   │   ├── social.py
│   │   ├── chat.py
│   │   ├── move.py
│   │   ├── ia.py
│   │   ├── pay.py
│   │   ├── marketplace.py
│   │   ├── job.py
│   │   ├── business.py
│   │   ├── mini_business.py
│   │   ├── school.py
│   │   ├── plug.py
│   │   └── trainer.py
│   ├── requirements.txt
│   └── Dockerfile
├── frontend/           # Aplicação Next.js
│   ├── pages/
│   │   ├── index.js
│   │   ├── cadastro.js
│   │   ├── life.js
│   │   ├── social.js
│   │   ├── chat.js
│   │   ├── move.js
│   │   ├── ia.js
│   │   ├── pay.js
│   │   ├── marketplace.js
│   │   ├── job.js
│   │   ├── business.js
│   │   ├── mini_business.js
│   │   ├── school.js
│   │   ├── plug.js
│   │   └── trainer.js
│   ├── package.json
│   ├── Dockerfile
│   └── README.md
├── docs/               # Documentação adicional
│   ├── modules_overview.md
│   ├── import_github.md
│   └── architecture.md
├── k8s/                # Manifests para Kubernetes
│   ├── deployment.yaml
│   └── service.yaml
├── .github/
│   └── workflows/
│       └── ci.yml
├── docker-compose.yaml
└── version.txt
```

## Licença

Distribuído sob a licença MIT. Consulte o arquivo `LICENSE` para obter mais detalhes.