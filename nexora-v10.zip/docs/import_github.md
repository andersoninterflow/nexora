# Importando o projeto para o GitHub

Este guia descreve como importar o projeto NEXORA v10 para um repositório GitHub. Siga os passos abaixo para criar um novo repositório e enviar os arquivos.

## 1. Crie um repositório vazio

1. Acesse [github.com/new](https://github.com/new).
2. Informe um nome (ex.: `nexora`) e escolha a visibilidade (pública ou privada).
3. **Não** selecione a opção de inicializar com README ou outros arquivos; o repositório deve estar vazio.
4. Clique em **Create repository**.

## 2. Baixe e extraia o arquivo ZIP

1. Faça download do arquivo `nexora-v10.zip` fornecido.
2. Extraia o conteúdo em um diretório local, por exemplo `~/projetos/nexora-v10`.

## 3. Inicialize o repositório Git

Abra um terminal dentro da pasta extraída e execute:

```bash
git init
git add .
git commit -m "chore: initial import (NEXORA v10)"
```

## 4. Adicione o repositório remoto

Substitua `SEU_USUARIO` e `SEU_REPOSITORIO` com seus dados e execute:

```bash
git branch -M main
git remote add origin https://github.com/SEU_USUARIO/SEU_REPOSITORIO.git
git push -u origin main
```

## 5. Configure GitHub Actions (opcional)

O projeto inclui um workflow de CI em `.github/workflows/ci.yml`. Para habilitar a publicação de imagens Docker e outros passos, configure secrets no repositório do GitHub conforme necessário (por exemplo, `DOCKER_USERNAME`, `DOCKER_PASSWORD`).

Após esses passos, seu projeto NEXORA v10 estará hospedado no GitHub e pronto para evoluir.