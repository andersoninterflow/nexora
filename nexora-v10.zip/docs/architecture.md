# Arquitetura técnica – NEXORA v10

Esta versão do NEXORA segue uma abordagem modular e escalável. O repositório é um monorepo que abriga tanto a API em Python (FastAPI) quanto a aplicação web em Next.js. Abaixo estão os principais aspectos da arquitetura técnica.

## Monorepo com dois aplicativos principais

* **backend/**: contém a API, organizada em módulos independentes. Cada módulo possui seu próprio arquivo de rotas dentro de `backend/modules`, facilitando a expansão e manutenção. A API utiliza FastAPI, permitindo documentação automática via OpenAPI.
* **frontend/**: implementa a interface do usuário em Next.js, com páginas dedicadas para cada módulo. A comunicação com a API é feita via requisições HTTP (axios).

## Compartilhamento de contratos

Como a API evolui, é recomendável extrair contratos (tipos ou esquemas JSON) para um pacote compartilhado e reutilizá‑los tanto no backend quanto no frontend. Para simplificar, este template não inclui ainda um pacote `shared`, mas a estrutura suporta essa expansão no futuro.

## Infraestrutura e DevOps

* **Docker**: ambos os aplicativos possuem um Dockerfile e podem ser orquestrados via `docker-compose.yaml`. Isso garante um ambiente de desenvolvimento reprodutível.
* **Kubernetes**: os manifests em `k8s/` exemplificam como implantar a API e o frontend em um cluster Kubernetes, definindo deploys e serviços.
* **GitHub Actions**: o workflow `ci.yml` demonstra como automatizar testes, builds e publicação de imagens Docker na sua plataforma de container registry.

## Escalabilidade

Cada módulo pode ser evoluído de forma independente. A camada de API foi segmentada para permitir a implantação em microsserviços no futuro, e o código do frontend pode ser particionado em pacotes ou apps internos se necessário.

## Segurança

Esta versão fornece apenas endpoints públicos de exemplo. Em um ambiente de produção, recomenda‑se a implementação de:

* Autenticação (JWT, OAuth2)
* Autorização baseada em papéis (RBAC)
* Validação de entrada com Pydantic ou biblioteca semelhante
* Criptografia de dados sensíveis e conformidade com LGPD/GDPR

## Próximos passos

* Implementar serviços reais para cada módulo (persistência, lógica de negócio e integrações externas).
* Criar banco de dados e modelos de dados (PostgreSQL sugerido).
* Adicionar testes automatizados.
* Implementar observabilidade (logs, métricas, tracing).

Esta arquitetura serve como base flexível para que o ecossistema NEXORA cresça de forma sustentável.