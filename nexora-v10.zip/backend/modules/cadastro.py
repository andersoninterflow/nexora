"""
Módulo de Cadastro.

Este módulo representa a porta de entrada do ecossistema NEXORA. Aqui são
gerenciados registros de contas para pessoas físicas e jurídicas, assim como
as permissões e perfis de acesso. As rotas fornecidas são exemplos de
endpoints e podem ser extendidas conforme as regras de negócio.
"""

from fastapi import APIRouter


router = APIRouter(prefix="/cadastro", tags=["Cadastro"])


@router.get("/pf", summary="Cadastro – Pessoa Física")
async def cadastro_pf():
    """Retorna informações de exemplo sobre cadastro de pessoa física."""
    return {
        "module": "cadastro",
        "user_type": "pf",
        "message": "Endpoint de exemplo para cadastro de pessoa física.",
    }


@router.get("/pj", summary="Cadastro – Pessoa Jurídica")
async def cadastro_pj():
    """Retorna informações de exemplo sobre cadastro de pessoa jurídica."""
    return {
        "module": "cadastro",
        "user_type": "pj",
        "message": "Endpoint de exemplo para cadastro de pessoa jurídica.",
    }


@router.get("/admin", summary="Cadastro – Painel Admin")
async def cadastro_admin():
    """Retorna informações de exemplo para o painel administrativo de cadastro."""
    return {
        "module": "cadastro",
        "user_type": "admin",
        "message": "Endpoint de exemplo para o painel admin de cadastro.",
    }