"""
Pacote de módulos do ecossistema NEXORA.

Cada módulo define um arquivo com um objeto `router` do FastAPI para
agrupar as rotas relacionadas às funcionalidades oferecidas.
"""

from . import cadastro  # noqa: F401
from . import life  # noqa: F401
from . import social  # noqa: F401
from . import chat  # noqa: F401
from . import move  # noqa: F401
from . import ia  # noqa: F401
from . import pay  # noqa: F401
from . import marketplace  # noqa: F401
from . import job  # noqa: F401
from . import business  # noqa: F401
from . import mini_business  # noqa: F401
from . import school  # noqa: F401
from . import plug  # noqa: F401
from . import trainer  # noqa: F401