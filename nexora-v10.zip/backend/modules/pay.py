"""
Módulo NEXORA Pay.

Sistema financeiro integrado do ecossistema. Oferece carteira digital,
pagamentos internos e externos, cashback e split de pagamentos.
"""

from fastapi import APIRouter


router = APIRouter(prefix="/pay", tags=["Pay"])


@router.get("/pf", summary="Pay – Pessoa Física")
async def pay_pf():
    """Endpoint de exemplo para carteira digital de pessoa física."""
    return {
        "module": "pay",
        "user_type": "pf",
        "message": "Endpoint de exemplo para pagamentos e carteira digital.",
    }


@router.get("/pj", summary="Pay – Pessoa Jurídica")
async def pay_pj():
    """Endpoint de exemplo para recebimentos e split de pagamentos corporativos."""
    return {
        "module": "pay",
        "user_type": "pj",
        "message": "Endpoint de exemplo para pagamentos em massa e relatórios.",
    }


@router.get("/admin", summary="Pay – Painel Admin")
async def pay_admin():
    """Retorna informações de exemplo para o painel administrativo do módulo Pay."""
    return {
        "module": "pay",
        "user_type": "admin",
        "message": "Endpoint de exemplo para painel admin do módulo Pay.",
    }