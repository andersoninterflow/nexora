"""
Módulo NEXORA Social.

Rede social integrada ao ecossistema, focada em conexões reais e profissionais.
Usuários podem ter perfis, participar de comunidades e eventos; empresas
divulgam produtos, campanhas e interagem com clientes.
"""

from fastapi import APIRouter


router = APIRouter(prefix="/social", tags=["Social"])


@router.get("/pf", summary="Social – Pessoa Física")
async def social_pf():
    """Exemplo de endpoint do feed social para pessoa física."""
    return {
        "module": "social",
        "user_type": "pf",
        "message": "Endpoint de exemplo para feed social de pessoa física.",
    }


@router.get("/pj", summary="Social – Pessoa Jurídica")
async def social_pj():
    """Exemplo de endpoint de campanhas sociais para empresas."""
    return {
        "module": "social",
        "user_type": "pj",
        "message": "Endpoint de exemplo para campanhas e páginas empresariais.",
    }


@router.get("/admin", summary="Social – Painel Admin")
async def social_admin():
    """Retorna informações de exemplo para o painel administrativo do módulo Social."""
    return {
        "module": "social",
        "user_type": "admin",
        "message": "Endpoint de exemplo para painel admin do módulo Social.",
    }