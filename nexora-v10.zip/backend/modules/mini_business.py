"""
Módulo NEXORA Mini Business.

Solução simplificada para pequenos negócios e autônomos, com catálogo,
pagamentos, agenda e divulgação.
"""

from fastapi import APIRouter


router = APIRouter(prefix="/mini-business", tags=["Mini Business"])


@router.get("/pf", summary="Mini Business – Pessoa Física")
async def mini_business_pf():
    """Endpoint de exemplo para autônomos ou microempreendedores."""
    return {
        "module": "mini_business",
        "user_type": "pf",
        "message": "Endpoint de exemplo para catálogo e agenda de microempreendedores.",
    }


@router.get("/pj", summary="Mini Business – Pessoa Jurídica")
async def mini_business_pj():
    """Endpoint de exemplo para pequenos negócios registrados como PJ."""
    return {
        "module": "mini_business",
        "user_type": "pj",
        "message": "Endpoint de exemplo para pequenos negócios com gestão simplificada.",
    }


@router.get("/admin", summary="Mini Business – Painel Admin")
async def mini_business_admin():
    """Retorna informações de exemplo para o painel administrativo do módulo Mini Business."""
    return {
        "module": "mini_business",
        "user_type": "admin",
        "message": "Endpoint de exemplo para painel admin do módulo Mini Business.",
    }