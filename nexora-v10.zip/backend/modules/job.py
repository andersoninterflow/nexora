"""
Módulo NEXORA Job.

Oferece oportunidades de trabalho, vagas freelance e portfólios digitais.
Empresas podem publicar vagas, contratar talentos e gerenciar contratos.
"""

from fastapi import APIRouter


router = APIRouter(prefix="/job", tags=["Job"])


@router.get("/pf", summary="Job – Pessoa Física")
async def job_pf():
    """Endpoint de exemplo para busca de empregos e oportunidades freelance."""
    return {
        "module": "job",
        "user_type": "pf",
        "message": "Endpoint de exemplo para busca de vagas e gestão de portfólio.",
    }


@router.get("/pj", summary="Job – Pessoa Jurídica")
async def job_pj():
    """Endpoint de exemplo para publicação de vagas e contratação."""
    return {
        "module": "job",
        "user_type": "pj",
        "message": "Endpoint de exemplo para empresas publicarem vagas e contratar talentos.",
    }


@router.get("/admin", summary="Job – Painel Admin")
async def job_admin():
    """Retorna informações de exemplo para o painel administrativo do módulo Job."""
    return {
        "module": "job",
        "user_type": "admin",
        "message": "Endpoint de exemplo para painel admin do módulo Job.",
    }