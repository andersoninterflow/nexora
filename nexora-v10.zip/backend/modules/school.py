"""
Módulo NEXORA School.

Plataforma de educação digital com cursos, certificados e trilhas de
aprendizado. Empresas podem oferecer treinamento corporativo e universidades
internas.
"""

from fastapi import APIRouter


router = APIRouter(prefix="/school", tags=["School"])


@router.get("/pf", summary="School – Pessoa Física")
async def school_pf():
    """Endpoint de exemplo para acesso a cursos por pessoa física."""
    return {
        "module": "school",
        "user_type": "pf",
        "message": "Endpoint de exemplo para navegação em cursos e certificados.",
    }


@router.get("/pj", summary="School – Pessoa Jurídica")
async def school_pj():
    """Endpoint de exemplo para programas de treinamento corporativo."""
    return {
        "module": "school",
        "user_type": "pj",
        "message": "Endpoint de exemplo para universidades internas e capacitação.",
    }


@router.get("/admin", summary="School – Painel Admin")
async def school_admin():
    """Retorna informações de exemplo para o painel administrativo do módulo School."""
    return {
        "module": "school",
        "user_type": "admin",
        "message": "Endpoint de exemplo para painel admin do módulo School.",
    }