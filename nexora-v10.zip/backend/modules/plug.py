"""
Módulo NEXORA Plug.

Responsável por integrações externas via APIs e extensões. Permite conectar
o ecossistema a sistemas de terceiros e fornecer pontos de extensão.
"""

from fastapi import APIRouter


router = APIRouter(prefix="/plug", tags=["Plug"])


@router.get("/pf", summary="Plug – Pessoa Física")
async def plug_pf():
    """Endpoint de exemplo para uso de plugins por pessoa física."""
    return {
        "module": "plug",
        "user_type": "pf",
        "message": "Endpoint de exemplo para integrações utilizadas por usuários.",
    }


@router.get("/pj", summary="Plug – Pessoa Jurídica")
async def plug_pj():
    """Endpoint de exemplo para integrações corporativas."""
    return {
        "module": "plug",
        "user_type": "pj",
        "message": "Endpoint de exemplo para APIs e extensões empresariais.",
    }


@router.get("/admin", summary="Plug – Painel Admin")
async def plug_admin():
    """Retorna informações de exemplo para o painel administrativo do módulo Plug."""
    return {
        "module": "plug",
        "user_type": "admin",
        "message": "Endpoint de exemplo para painel admin do módulo Plug.",
    }