"""
Módulo NEXORA Trainer.

Focado em mentoria, coaching e treinamento para indivíduos e equipes.
Permite conectar mentores, agendar sessões e acompanhar evolução.
"""

from fastapi import APIRouter


router = APIRouter(prefix="/trainer", tags=["Trainer"])


@router.get("/pf", summary="Trainer – Pessoa Física")
async def trainer_pf():
    """Endpoint de exemplo para usuários buscando mentoria ou coaching."""
    return {
        "module": "trainer",
        "user_type": "pf",
        "message": "Endpoint de exemplo para sessão de mentoria pessoal.",
    }


@router.get("/pj", summary="Trainer – Pessoa Jurídica")
async def trainer_pj():
    """Endpoint de exemplo para programas de capacitação corporativa."""
    return {
        "module": "trainer",
        "user_type": "pj",
        "message": "Endpoint de exemplo para treinamentos de equipes e mentoria corporativa.",
    }


@router.get("/admin", summary="Trainer – Painel Admin")
async def trainer_admin():
    """Retorna informações de exemplo para o painel administrativo do módulo Trainer."""
    return {
        "module": "trainer",
        "user_type": "admin",
        "message": "Endpoint de exemplo para painel admin do módulo Trainer.",
    }