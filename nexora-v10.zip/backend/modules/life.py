"""
Módulo NEXORA Life.

Focado em qualidade de vida, saúde, rotina e bem‑estar. Este módulo permite
a usuários acompanhar hábitos, metas pessoais e conectar‑se com profissionais
de saúde. Empresas podem fornecer programas de bem‑estar aos colaboradores.
"""

from fastapi import APIRouter


router = APIRouter(prefix="/life", tags=["Life"])


@router.get("/pf", summary="Life – Pessoa Física")
async def life_pf():
    """Exemplo de endpoint para usuário pessoa física no módulo Life."""
    return {
        "module": "life",
        "user_type": "pf",
        "message": "Endpoint de exemplo para rotina e bem‑estar de pessoa física.",
    }


@router.get("/pj", summary="Life – Pessoa Jurídica")
async def life_pj():
    """Exemplo de endpoint para empresas no módulo Life."""
    return {
        "module": "life",
        "user_type": "pj",
        "message": "Endpoint de exemplo para programas de bem‑estar corporativo.",
    }


@router.get("/admin", summary="Life – Painel Admin")
async def life_admin():
    """Retorna informações de exemplo para o painel administrativo do módulo Life."""
    return {
        "module": "life",
        "user_type": "admin",
        "message": "Endpoint de exemplo para painel admin do módulo Life.",
    }