"""
Módulo NEXORA Move.

Oferece soluções de mobilidade inteligente. Usuários podem solicitar transporte
sob demanda, enquanto empresas gerenciam frotas e logística urbana.
"""

from fastapi import APIRouter


router = APIRouter(prefix="/move", tags=["Move"])


@router.get("/pf", summary="Move – Pessoa Física")
async def move_pf():
    """Endpoint de exemplo para solicitação de transporte por pessoa física."""
    return {
        "module": "move",
        "user_type": "pf",
        "message": "Endpoint de exemplo para mobilidade sob demanda.",
    }


@router.get("/pj", summary="Move – Pessoa Jurídica")
async def move_pj():
    """Endpoint de exemplo para gerenciamento de frota corporativa."""
    return {
        "module": "move",
        "user_type": "pj",
        "message": "Endpoint de exemplo para logística urbana corporativa.",
    }


@router.get("/admin", summary="Move – Painel Admin")
async def move_admin():
    """Retorna informações de exemplo para o painel administrativo do módulo Move."""
    return {
        "module": "move",
        "user_type": "admin",
        "message": "Endpoint de exemplo para painel admin do módulo Move.",
    }