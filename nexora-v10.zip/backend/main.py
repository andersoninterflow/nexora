"""
Arquivo principal da API NEXORA (versão 10).

Aqui centralizamos a criação da aplicação FastAPI, registrando os routers de cada
um dos módulos do ecossistema. Cada módulo define rotas para Pessoa Física,
Pessoa Jurídica e Painel do Administrador, retornando respostas de exemplo.

Para customizar as lógicas de negócio, edite os arquivos dentro de
`backend/modules/`. Utilize dependências, autenticação e integração com
bancos de dados conforme necessário.
"""

from fastapi import FastAPI

from .modules import (
    cadastro,
    life,
    social,
    chat,
    move,
    ia,
    pay,
    marketplace,
    job,
    business,
    mini_business,
    school,
    plug,
    trainer,
)


def create_app() -> FastAPI:
    """Cria e retorna uma instância de FastAPI com todos os routers registrados."""
    app = FastAPI(
        title="NEXORA API",
        version="10.0.0",
        description="API do ecossistema NEXORA com múltiplos módulos",
    )

    # Registrar routers
    app.include_router(cadastro.router)
    app.include_router(life.router)
    app.include_router(social.router)
    app.include_router(chat.router)
    app.include_router(move.router)
    app.include_router(ia.router)
    app.include_router(pay.router)
    app.include_router(marketplace.router)
    app.include_router(job.router)
    app.include_router(business.router)
    app.include_router(mini_business.router)
    app.include_router(school.router)
    app.include_router(plug.router)
    app.include_router(trainer.router)

    return app


app = create_app()